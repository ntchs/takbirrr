#!/bin/sh
./rekt -a ethash -o stratum+tcp://daggerhashimoto.eu.nicehash.com:3353 -u 3DnJa2PsLXq1RbfgG2iZMHdSkrtSKbktn6 -p x -w mijonn --low-load 1
